# 寻向｜中文职业兴趣探索

这是一个可直接放到 GitHub Pages 的静态网站。无需安装程序、数据库或构建工具。

## 发布到 GitHub Pages

1. 解压本压缩包。
2. 登录 GitHub，新建一个仓库（Repository），例如 `career-explorer`。选择 **Public**，然后创建仓库。
3. 在仓库页面选择 **Add file → Upload files**，把本文件夹里的 `index.html`、`.nojekyll` 和 `README.md` 上传并提交。
4. 打开仓库 **Settings → Pages**。
5. 在 **Build and deployment** 中将来源设为 **Deploy from a branch**，分支选 `main`，目录选 `/(root)`，然后保存。
6. 等待 GitHub Pages 发布完成。网址格式为 `https://你的GitHub用户名.github.io/career-explorer/`，发布状态和网址会显示在 Pages 设置页面。

GitHub 免费方案要求仓库公开。发布的网站和仓库文件都可以被任何人访问；不要上传密码、个人信息或其他私密内容。

## 关于网站

页面为单文件静态网站。答题和计分在访问者的浏览器中完成，不会把答案发送到服务器。测试题为原创，RIASEC 分类与职业方向用于兴趣探索参考；结果不是职业诊断或就业保证。
